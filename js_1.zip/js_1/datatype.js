let num=10
console.log(typeof(num))
let f_num=10.9
console.log(typeof(f_num))//number

let str="hello"
console.log(typeof(str))//string

let n_str=1.24
console.log(typeof(n_str))//string
let bool=true
console.log(typeof(bool))//boolean

let ab
console.log(ab)
console.log(typeof(ab))//undefined

let n=null
console.log(n);//null
console.log(typeof(n));//object
// escape chars(\)
console.log("hellow All");
console.log("GOOD \*AFTERNOON\*");
console.log('I Am \"saranya\"');
console.log(`parul
      university`);